### CSC 349, Assignment 8

Required files:
  * `compile.sh`
  * `run.sh`

Optional files:
  * `*.sh`
  * `*.py`
  * `*.java`
  * `*.clj`
  * `*.kt`
  * `*.js`
